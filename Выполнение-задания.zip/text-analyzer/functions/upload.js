const { removeStopwords } = require('stopword');

// Функция для подсчета частоты слов в тексте
function wordFrequency(text) {
  // Преобразование текста в нижний регистр и удаление специальных символов
  const words = text.toLowerCase()
    .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, '')
    .split(/\s+/);

  // Удаление стоп-слов (часто используемых слов без смысловой нагрузки)
  const filteredWords = removeStopwords(words);

  const wordCount = {};

  // Подсчет частоты для каждого слова
  filteredWords.forEach(word => {
    if (word.length > 1) { // Игнорировать слова длиной 1 символ
      if (wordCount[word]) {
        wordCount[word]++;
      } else {
        wordCount[word] = 1;
      }
    }
  });

  return wordCount;
}

// Функция для расчета IDF (Inverse Document Frequency)
function calculateIDF(wordFreq, totalWords) {
  const idfValues = {};

  for (const word in wordFreq) {
    // Формула IDF: log(общее количество слов / частота слова)
    idfValues[word] = Math.log(totalWords / wordFreq[word]);
  }

  return idfValues;
}

exports.handler = async function(event, context) {
  // Проверяем метод запроса
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: 'Method Not Allowed' })
    };
  }

  try {
    // Получаем данные из тела запроса
    let text = '';

    // В реальной serverless функции нам нужно было бы обрабатывать multipart/form-data
    // Для упрощения, предположим, что текст передается напрямую в теле запроса
    if (event.body) {
      try {
        const body = JSON.parse(event.body);
        text = body.text || '';
      } catch (e) {
        text = event.body;
      }
    }

    if (!text) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Текст не предоставлен' })
      };
    }

    // Подсчет частоты слов
    const freq = wordFrequency(text);

    // Подсчет общего количества слов
    const totalWords = Object.values(freq).reduce((sum, count) => sum + count, 0);

    // Расчет IDF
    const idf = calculateIDF(freq, totalWords);

    // Создание массива результатов
    const results = Object.keys(freq).map(word => ({
      word,
      frequency: freq[word],
      idf: idf[word]
    }));

    // Сортировка по IDF в убывающем порядке
    results.sort((a, b) => b.idf - a.idf);

    // Взять первые 50 результатов
    const top50 = results.slice(0, 50);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(top50)
    };
  } catch (error) {
    console.error('Error:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Ошибка обработки запроса' })
    };
  }
};
