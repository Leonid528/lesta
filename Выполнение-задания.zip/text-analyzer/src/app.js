document.addEventListener('DOMContentLoaded', () => {
  const uploadForm = document.getElementById('uploadForm');
  const textFileInput = document.getElementById('textFile');
  const uploadButton = document.getElementById('uploadButton');
  const loadingIndicator = document.getElementById('loadingIndicator');
  const resultsSection = document.getElementById('resultsSection');
  const resultsTableBody = document.getElementById('resultsTableBody');
  const pagination = document.getElementById('pagination');
  const totalResultsInfo = document.getElementById('totalResultsInfo');
  const itemsPerPageSelect = document.getElementById('itemsPerPage');

  // Для хранения результатов анализа
  let analysisResults = [];

  // Настройки пагинации
  let currentPage = 1;
  let itemsPerPage = 50;
  let totalPages = 0;

  // Массив стоп-слов (часто используемые слова без смысловой нагрузки)
  const stopWords = [
    'и', 'в', 'на', 'с', 'по', 'для', 'не', 'от', 'за', 'к', 'из', 'у', 'о', 'а', 'но', 'же', 'то', 'да',
    'или', 'бы', 'что', 'кто', 'как', 'который', 'такой', 'этот', 'тот', 'весь', 'быть', 'мочь', 'сделать',
    'один', 'два', 'три', 'четыре', 'пять', 'если'
  ];

  // Функция для подсчета частоты слов в тексте
  function wordFrequency(text) {
    // Преобразование текста в нижний регистр и удаление специальных символов
    const words = text.toLowerCase()
      .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, '')
      .split(/\s+/);

    // Удаление стоп-слов
    const filteredWords = words.filter(word => !stopWords.includes(word));

    const wordCount = {};

    // Подсчет частоты для каждого слова
    filteredWords.forEach(word => {
      if (word.length > 1) { // Игнорировать слова длиной 1 символ
        if (wordCount[word]) {
          wordCount[word]++;
        } else {
          wordCount[word] = 1;
        }
      }
    });

    return wordCount;
  }

  // Функция для расчета IDF (Inverse Document Frequency)
  function calculateIDF(wordFreq, totalWords) {
    const idfValues = {};

    for (const word in wordFreq) {
      // Формула IDF: log(общее количество слов / частота слова)
      idfValues[word] = Math.log(totalWords / wordFreq[word]);
    }

    return idfValues;
  }

  // Функция для отображения результатов с пагинацией
  function displayResultsPage(page) {
    // Очистка таблицы
    resultsTableBody.innerHTML = '';

    // Рассчитать индексы начала и конца для текущей страницы
    const startIndex = (page - 1) * itemsPerPage;
    const endIndex = Math.min(startIndex + itemsPerPage, analysisResults.length);

    // Заполнение таблицы данными текущей страницы
    for (let i = startIndex; i < endIndex; i++) {
      const item = analysisResults[i];
      const row = document.createElement('tr');

      row.innerHTML = `
        <td>${i + 1}</td>
        <td>${item.word}</td>
        <td>${item.frequency}</td>
        <td>${item.idf.toFixed(4)}</td>
      `;

      resultsTableBody.appendChild(row);
    }

    // Обновить информацию о результатах
    totalResultsInfo.textContent = `Показано ${startIndex + 1}-${endIndex} из ${analysisResults.length} результатов`;

    // Обновить пагинацию
    updatePagination();
  }

  // Функция для обновления пагинации
  function updatePagination() {
    pagination.innerHTML = '';

    // Рассчитать общее количество страниц
    totalPages = Math.ceil(analysisResults.length / itemsPerPage);

    // Если меньше 2 страниц, скрыть пагинацию
    if (totalPages <= 1) {
      pagination.classList.add('hidden');
      return;
    }

    pagination.classList.remove('hidden');

    // Добавить кнопку "Предыдущая"
    const prevButton = document.createElement('button');
    prevButton.classList.add('pagination-button');
    prevButton.textContent = '«';
    prevButton.disabled = currentPage === 1;
    prevButton.addEventListener('click', () => {
      if (currentPage > 1) {
        currentPage--;
        displayResultsPage(currentPage);
      }
    });
    pagination.appendChild(prevButton);

    // Определить, какие страницы показывать
    let startPage = Math.max(1, currentPage - 2);
    let endPage = Math.min(totalPages, startPage + 4);

    // Если показываем меньше 5 страниц, сдвинуть стартовую страницу
    if (endPage - startPage < 4) {
      startPage = Math.max(1, endPage - 4);
    }

    // Добавить кнопку для первой страницы, если не включена в диапазон
    if (startPage > 1) {
      const firstPageButton = document.createElement('button');
      firstPageButton.classList.add('pagination-button');
      firstPageButton.textContent = '1';
      firstPageButton.addEventListener('click', () => {
        currentPage = 1;
        displayResultsPage(currentPage);
      });
      pagination.appendChild(firstPageButton);

      // Добавить многоточие, если начинаем не со второй страницы
      if (startPage > 2) {
        const ellipsis = document.createElement('span');
        ellipsis.classList.add('pagination-ellipsis');
        ellipsis.textContent = '...';
        pagination.appendChild(ellipsis);
      }
    }

    // Добавить кнопки для страниц в диапазоне
    for (let i = startPage; i <= endPage; i++) {
      const pageButton = document.createElement('button');
      pageButton.classList.add('pagination-button');
      if (i === currentPage) {
        pageButton.classList.add('active');
      }
      pageButton.textContent = i;
      pageButton.addEventListener('click', () => {
        currentPage = i;
        displayResultsPage(currentPage);
      });
      pagination.appendChild(pageButton);
    }

    // Добавить многоточие и последнюю страницу, если не включена в диапазон
    if (endPage < totalPages) {
      // Добавить многоточие, если не заканчиваем предпоследней страницей
      if (endPage < totalPages - 1) {
        const ellipsis = document.createElement('span');
        ellipsis.classList.add('pagination-ellipsis');
        ellipsis.textContent = '...';
        pagination.appendChild(ellipsis);
      }

      const lastPageButton = document.createElement('button');
      lastPageButton.classList.add('pagination-button');
      lastPageButton.textContent = totalPages;
      lastPageButton.addEventListener('click', () => {
        currentPage = totalPages;
        displayResultsPage(currentPage);
      });
      pagination.appendChild(lastPageButton);
    }

    // Добавить кнопку "Следующая"
    const nextButton = document.createElement('button');
    nextButton.classList.add('pagination-button');
    nextButton.textContent = '»';
    nextButton.disabled = currentPage === totalPages;
    nextButton.addEventListener('click', () => {
      if (currentPage < totalPages) {
        currentPage++;
        displayResultsPage(currentPage);
      }
    });
    pagination.appendChild(nextButton);
  }

  // Обработчик изменения количества элементов на странице
  itemsPerPageSelect.addEventListener('change', () => {
    itemsPerPage = parseInt(itemsPerPageSelect.value);
    currentPage = 1; // Сбросить на первую страницу при изменении
    displayResultsPage(currentPage);
  });

  // Функция для экспорта результатов в CSV формат
  function exportToCSV(data) {
    // Заголовок для CSV
    let csvContent = "№,Слово,Встречается в тексте (раз),IDF (Обратная частота)\n";

    // Добавление данных
    data.forEach((item, index) => {
      csvContent += `${index + 1},"${item.word}",${item.frequency},${item.idf.toFixed(4)}\n`;
    });

    // Создание Blob и ссылки для скачивания
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');

    // Настройка параметров ссылки
    link.setAttribute('href', url);
    link.setAttribute('download', 'text_analysis_results.csv');
    link.style.display = 'none';

    // Добавление ссылки в DOM, клик по ней и удаление
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // Функция для экспорта результатов в JSON формат
  function exportToJSON(data) {
    // Форматирование данных для JSON
    const jsonData = data.map((item, index) => ({
      index: index + 1,
      word: item.word,
      frequency: item.frequency,
      idf: parseFloat(item.idf.toFixed(4))
    }));

    // Создание Blob и ссылки для скачивания
    const blob = new Blob([JSON.stringify(jsonData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');

    // Настройка параметров ссылки
    link.setAttribute('href', url);
    link.setAttribute('download', 'text_analysis_results.json');
    link.style.display = 'none';

    // Добавление ссылки в DOM, клик по ней и удаление
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // Функция для экспорта результатов в текстовый формат
  function exportToTXT(data) {
    let textContent = "Результаты анализа текста\n";
    textContent += "==============================\n\n";
    textContent += "№\tСлово\t\tВстречается в тексте (раз)\tIDF (Обратная частота)\n";

    // Добавление данных
    data.forEach((item, index) => {
      textContent += `${index + 1}\t${item.word.padEnd(15)}\t${item.frequency}\t\t\t${item.idf.toFixed(4)}\n`;
    });

    // Создание Blob и ссылки для скачивания
    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');

    // Настройка параметров ссылки
    link.setAttribute('href', url);
    link.setAttribute('download', 'text_analysis_results.txt');
    link.style.display = 'none';

    // Добавление ссылки в DOM, клик по ней и удаление
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // Обработчик для кнопок экспорта
  document.addEventListener('click', (e) => {
    if (e.target.matches('#exportCSV')) {
      exportToCSV(analysisResults);
    } else if (e.target.matches('#exportJSON')) {
      exportToJSON(analysisResults);
    } else if (e.target.matches('#exportTXT')) {
      exportToTXT(analysisResults);
    }
  });

  // Отображение имени выбранного файла
  textFileInput.addEventListener('change', (e) => {
    const fileName = e.target.files[0]?.name || 'Выберите текстовый файл';
    const label = textFileInput.nextElementSibling;
    label.textContent = fileName;
  });

  // Обработка отправки формы
  uploadForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Проверка выбран ли файл
    if (!textFileInput.files[0]) {
      alert('Пожалуйста, выберите текстовый файл');
      return;
    }

    // Показать индикатор загрузки и скрыть кнопку
    uploadButton.disabled = true;
    loadingIndicator.classList.remove('hidden');
    resultsSection.classList.add('hidden');

    try {
      // Чтение содержимого файла на клиенте
      const file = textFileInput.files[0];
      const fileContent = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (event) => resolve(event.target.result);
        reader.onerror = (error) => reject(error);
        reader.readAsText(file);
      });

      // Анализ содержимого файла
      const freq = wordFrequency(fileContent);

      // Подсчет общего количества слов
      const totalWords = Object.values(freq).reduce((sum, count) => sum + count, 0);

      // Расчет IDF
      const idf = calculateIDF(freq, totalWords);

      // Создание массива результатов
      const results = Object.keys(freq).map(word => ({
        word,
        frequency: freq[word],
        idf: idf[word]
      }));

      // Сортировка по IDF в убывающем порядке
      results.sort((a, b) => b.idf - a.idf);

      // Сохранение полных результатов для экспорта и пагинации
      analysisResults = results;

      // Сбросить на первую страницу и отобразить результаты
      currentPage = 1;
      displayResultsPage(currentPage);

      // Показать результаты и секцию пагинации
      resultsSection.classList.remove('hidden');

      // Показать кнопки экспорта
      document.getElementById('exportButtons').classList.remove('hidden');

    } catch (error) {
      console.error('Ошибка:', error);
      alert(`Произошла ошибка: ${error.message}`);
    } finally {
      // Скрыть индикатор загрузки и разблокировать кнопку
      loadingIndicator.classList.add('hidden');
      uploadButton.disabled = false;
    }
  });
});
