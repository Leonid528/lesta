const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { removeStopwords } = require('stopword');
const natural = require('natural');

const app = express();
const port = 3000;

// Создание директории uploads, если она не существует
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir);
}

// Настройка статической директории
app.use(express.static(path.join(__dirname, 'src')));

// Настройка multer для загрузки файлов
const upload = multer({ dest: uploadsDir });

// Функция для подсчета частоты слов в тексте
function wordFrequency(text) {
  // Преобразование текста в нижний регистр и удаление специальных символов
  const words = text.toLowerCase()
    .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, '')
    .split(/\s+/);

  // Удаление стоп-слов (часто используемых слов без смысловой нагрузки)
  const filteredWords = removeStopwords(words);

  const wordCount = {};

  // Подсчет частоты для каждого слова
  filteredWords.forEach(word => {
    if (word.length > 1) { // Игнорировать слова длиной 1 символ
      if (wordCount[word]) {
        wordCount[word]++;
      } else {
        wordCount[word] = 1;
      }
    }
  });

  return wordCount;
}

// Функция для расчета IDF (Inverse Document Frequency)
function calculateIDF(wordFreq, totalWords) {
  const idfValues = {};

  for (const word in wordFreq) {
    // Формула IDF: log(общее количество слов / частота слова)
    idfValues[word] = Math.log(totalWords / wordFreq[word]);
  }

  return idfValues;
}

// Маршрут для загрузки файла
app.post('/upload', upload.single('textFile'), (req, res) => {
  // Проверка, что файл загружен
  if (!req.file) {
    return res.status(400).json({ error: 'Файл не был загружен' });
  }

  // Чтение содержимого файла
  fs.readFile(req.file.path, 'utf8', (err, data) => {
    if (err) {
      return res.status(500).json({ error: 'Ошибка чтения файла' });
    }

    // Подсчет частоты слов
    const freq = wordFrequency(data);

    // Подсчет общего количества слов
    const totalWords = Object.values(freq).reduce((sum, count) => sum + count, 0);

    // Расчет IDF
    const idf = calculateIDF(freq, totalWords);

    // Создание массива результатов
    const results = Object.keys(freq).map(word => ({
      word,
      frequency: freq[word],
      idf: idf[word]
    }));

    // Сортировка по IDF в убывающем порядке
    results.sort((a, b) => b.idf - a.idf);

    // Взять первые 50 результатов
    const top50 = results.slice(0, 50);

    // Удаление временного файла
    fs.unlinkSync(req.file.path);

    res.json(top50);
  });
});

// Слушать порт
app.listen(port, '0.0.0.0', () => {
  console.log(`Сервер запущен на порту ${port}`);
});
