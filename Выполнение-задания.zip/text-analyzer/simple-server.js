const express = require('express');
const app = express();
const port = 3000;

// Статический сервер
app.use(express.static('src'));

// Простой маршрут для тестирования API
app.post('/upload', express.json(), (req, res) => {
  res.json([
    { word: "тестовое", frequency: 10, idf: 2.3026 },
    { word: "слово", frequency: 5, idf: 2.9957 },
    { word: "анализ", frequency: 3, idf: 3.5065 }
  ]);
});

// Запуск сервера
app.listen(port, '0.0.0.0', () => {
  console.log(`Тестовый сервер запущен на порту ${port}`);
});
